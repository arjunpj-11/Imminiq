// apps/api/src/modules/trackers/application/use-cases/ask-lesson-question-solution-doubt.usecase.ts

import { TrackerApplicationError } from '../errors/tracker-application.error'
import type { TrackerMapperContract } from '../mappers/tracker.mapper'
import type { TrackerRepositoryContract } from '../../domain/repositories/tracker.repository.interface'
import type { TrackerAIServiceContract } from '../../domain/services/tracker-ai.service.interface'
import type { QuestionHasherServiceContract } from '../../domain/services/question-hasher.service.interface'

type AskLessonQuestionSolutionDoubtResultDto = ReturnType<
  TrackerMapperContract['toLessonQuestionSolutionDoubtAnswerDto']
>

const getDocumentId = (document: unknown) => {
  const doc = document as { _id?: unknown }

  if (typeof doc._id === 'string') {
    return doc._id
  }

  if (doc._id && typeof doc._id === 'object' && 'toString' in doc._id) {
    return doc._id.toString()
  }

  return null
}

export class AskLessonQuestionSolutionDoubtUseCase {
  constructor(
    private readonly trackerRepository: TrackerRepositoryContract,
    private readonly trackerAIService: TrackerAIServiceContract,
    private readonly questionHasher: QuestionHasherServiceContract,
    private readonly trackerMapper: TrackerMapperContract,
  ) {}

  async execute(input: {
    trackerId: string
    subtopicId: string
    userId: string
    question: string
    message: string
  }): Promise<AskLessonQuestionSolutionDoubtResultDto> {
    const tracker = await this.trackerRepository.findOwnedTrackerById({
      trackerId: input.trackerId,
      userId: input.userId,
    })

    if (!tracker) {
      throw TrackerApplicationError.trackerNotFound('Tracker not found')
    }

    const lesson = await this.trackerRepository.findLessonBySubtopicId({
      trackerId: input.trackerId,
      subtopicId: input.subtopicId,
      userId: input.userId,
    })

    if (!lesson) {
      throw TrackerApplicationError.lessonNotGenerated(
        'Generate the lesson before asking solution doubt',
      )
    }

    const questionHash = this.questionHasher.hash(input.question)

    const solution = await this.trackerRepository.findLessonQuestionSolution({
      trackerId: input.trackerId,
      subtopicId: input.subtopicId,
      userId: input.userId,
      questionHash,
    })

    if (!solution) {
      throw TrackerApplicationError.solutionNotGenerated(
        'Generate the solution before asking doubts',
      )
    }

    const typedSolution = solution as {
      _id?: unknown
      solution?: string
    }

    const solutionText = typedSolution.solution || ''

    if (!solutionText) {
      throw TrackerApplicationError.solutionEmpty('Saved solution is empty')
    }

    const lessonId = getDocumentId(lesson)
    const solutionId = getDocumentId(solution)

    await this.trackerRepository.createLessonQuestionSolutionDoubt({
      trackerId: input.trackerId,
      subtopicId: input.subtopicId,
      userId: input.userId,
      lessonId,
      solutionId,
      question: input.question,
      questionHash,
      role: 'user',
      content: input.message,
    })

    const history =
      await this.trackerRepository.getLessonQuestionSolutionDoubts({
        trackerId: input.trackerId,
        subtopicId: input.subtopicId,
        userId: input.userId,
        questionHash,
      })

    const messages = history.map((item) => {
      const message = item as {
        role: 'user' | 'assistant'
        content: string
      }

      return {
        role: message.role,
        content: message.content,
      }
    })

 const answer =
  await this.trackerAIService.chatWithLessonQuestionSolutionDoubt({
    lessonTitle: lesson.title,
    lessonExplanation: lesson.explanation,
    question: input.question,
    solution: solutionText,
    messages,
  })
    await this.trackerRepository.createLessonQuestionSolutionDoubt({
      trackerId: input.trackerId,
      subtopicId: input.subtopicId,
      userId: input.userId,
      lessonId,
      solutionId,
      question: input.question,
      questionHash,
      role: 'assistant',
      content: answer,
    })

    return this.trackerMapper.toLessonQuestionSolutionDoubtAnswerDto({
      answer,
    })
  }
}