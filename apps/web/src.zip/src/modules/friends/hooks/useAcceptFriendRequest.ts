import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { AxiosError } from "axios";

import api from "../../../lib/axios";
import { FRIENDS_ENDPOINTS } from "../constants/friends.constants";
import type {
  AcceptFriendRequestResponse,
  FriendRequestActionInput,
  FriendsApiErrorResponse,
  FriendsApiResponse,
} from "../types/friends.types";
import { friendsQueryKeys } from "./friends-query-keys";

export const useAcceptFriendRequest = () => {
  const queryClient = useQueryClient();

  return useMutation<
    AcceptFriendRequestResponse,
    AxiosError<FriendsApiErrorResponse>,
    FriendRequestActionInput
  >({
    mutationFn: async ({ requestId }) => {
      const response = await api.post<
        FriendsApiResponse<AcceptFriendRequestResponse>
      >(FRIENDS_ENDPOINTS.acceptRequest(requestId));

      return response.data.data;
    },
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({
          queryKey: friendsQueryKeys.lists(),
        }),
        queryClient.invalidateQueries({
          queryKey: friendsQueryKeys.requests(),
        }),
        queryClient.invalidateQueries({
          queryKey: friendsQueryKeys.searches(),
        }),
      ]);
    },
  });
};
